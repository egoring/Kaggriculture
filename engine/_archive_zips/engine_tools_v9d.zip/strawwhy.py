import importlib.util,sys,collections
from kaggle_environments import make
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m.agent
def passer(obs,cfg=None): return {"farmer":["PASS"],"hands":[],"market":[]}
env=make("kaggriculture",configuration={"seed":int(sys.argv[2])}); env.run([load(sys.argv[1],"E"),passer]); st=env.steps
planted=collections.Counter(); harv=collections.Counter(); fert=collections.Counter(); ferttot=0
for i in range(719):
    o=st[i][0].observation["farms"][0]; a=st[i+1][0].action
    pos=[tuple(o["farmer"])]+[tuple(p) for p in o["hands"]]; acts=[a.get("farmer")]+list(a.get("hands") or [])
    for p,ac in zip(pos,acts):
        if not ac: continue
        t=o["tiles"][p[1]][p[0]]
        if ac[0]=="PLANT": planted[(i//24,ac[1])]+=1
        if ac[0]=="HARVEST" and isinstance(t,dict) and t.get("crop")=="STRAWBERRY": harv[i//24]+=t["yield_units"]
        if ac[0]=="FERTILIZE" and isinstance(t,dict): fert[t.get("crop")]+=1
sp={d:n for (d,c),n in planted.items() if c=="STRAWBERRY"}
print("straw planted by day",dict(sorted(sp.items())),"total",sum(sp.values()))
print("straw harvested by day",dict(sorted(harv.items())),"total",sum(harv.values()))
print("fertilize by crop",dict(fert))
