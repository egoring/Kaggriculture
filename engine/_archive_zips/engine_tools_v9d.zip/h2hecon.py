import importlib.util,sys,pickle
from kaggle_environments import make
from matrix import mk
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m.agent
A=load(sys.argv[1],"A"); B=mk(pickle.load(open("cols_v9.pkl","rb"))[sys.argv[2]])
env=make("kaggriculture",configuration={"seed":int(sys.argv[3])}); env.run([A,B]); st=env.steps
for d in range(int(sys.argv[4]),int(sys.argv[5])+1):
    for seat in (0,1):
        line=[]; inc=0
        for i in range(d*24,d*24+24):
            m=(st[i+1][seat].action or {}).get("market") or []
            pr=st[i][seat].observation["market"]["prices"]
            for o in m:
                if o[0]=="SELL": inc+=pr[o[1]]*int(o[2])
            if m: line.append(f"h{i%24}:"+",".join(f"{o[0][:4]}{'' if len(o)<2 else ' '+o[1][:3]}{'' if len(o)<3 else ' '+str(o[2])}" for o in m if o[0]!="HIRE")+(f"+H{sum(1 for o in m if o[0]=='HIRE')}" if any(o[0]=="HIRE" for o in m) else ""))
        f=st[d*24+23][seat].observation["farms"][seat]
        print(f"D{d} s{seat} end ${int(f['money'])} sales≈{int(inc)} | "+" | ".join(line))
