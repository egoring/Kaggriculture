import importlib.util,sys,os,multiprocessing as mp
from kaggle_environments import make
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m.agent
def passer(obs,cfg=None): return {"farmer":["PASS"],"hands":[],"market":[]}
def run(a):
    f,sd=a; env=make("kaggriculture",configuration={"seed":sd}); env.run([load(f,"E"),passer]); st=env.steps
    esc=0; weeded=0; unfed=0; unw=0; sold={}
    for d in range(29):
        a_=st[d*24+23][0].observation["farms"][0]["tiles"]; b_=st[d*24+24][0].observation["farms"][0]["tiles"]
        for y in range(10):
            for x in range(10):
                ta,tb=a_[y][x],b_[y][x]
                if isinstance(ta,dict) and ta.get("animal"):
                    if not (isinstance(tb,dict) and tb.get("animal")): esc+=1
                    if not ta.get("fed_today"): unfed+=1
                if isinstance(ta,dict) and ta.get("kind")=="PLANT":
                    if isinstance(tb,dict) and tb.get("kind")=="WEED": weeded+=1
                    if not ta.get("watered_today") and ta.get("consecutive_unwatered",0)>=1: unw+=1
    for i in range(719):
        for o in st[i+1][0].action.get("market") or []:
            if o[0]=="SELL": sold[o[1]]=sold.get(o[1],0)+int(o[2])
    return sd,st[-1][0].reward,esc,weeded,unfed,sold
if __name__=="__main__":
    f=sys.argv[1]; seeds=[int(x) for x in sys.argv[2].split(",")]
    with mp.Pool(2) as p: res=p.map(run,[(f,s) for s in seeds])
    n=len(res); tot={}
    for r in res:
        for k,v in r[5].items(): tot[k]=tot.get(k,0)+v
    print(f, {k:v for k,v in os.environ.items() if k.startswith("KG_")}, "solo mean", round(sum(r[1] for r in res)/n), "escapes %.1f weeded %.1f unfed-days %.1f"%(sum(r[2] for r in res)/n,sum(r[3] for r in res)/n,sum(r[4] for r in res)/n))
    print("  sold/game", {k:round(v/n) for k,v in sorted(tot.items())})
    print("  ", [int(r[1]) for r in res])
