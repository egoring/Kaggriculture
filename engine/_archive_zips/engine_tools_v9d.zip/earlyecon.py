import importlib.util,sys
from kaggle_environments import make
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m.agent
def passer(obs,cfg=None): return {"farmer":["PASS"],"hands":[],"market":[]}
env=make("kaggriculture",configuration={"seed":int(sys.argv[2])}); env.run([load(sys.argv[1],"E"),passer]); st=env.steps
for d in range(int(sys.argv[3]),int(sys.argv[4])+1):
    line=[]
    for i in range(d*24,d*24+24):
        m=st[i+1][0].action.get("market") or []
        if m: line.append(f"h{i%24}:"+",".join(f"{o[0][:4]}{'' if len(o)<2 else ' '+o[1][:4]}{'' if len(o)<3 else ' '+str(o[2])}" for o in m))
    f=st[d*24+23][0].observation["farms"][0]; pv=st[d*24+23][0].observation["private"]
    print(f"D{d} end money {int(f['money'])} shed {pv['shed']} seeds {pv['seeds']}"); print("   "+" | ".join(line))
