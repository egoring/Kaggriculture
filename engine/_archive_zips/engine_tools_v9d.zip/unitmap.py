import importlib.util,sys,collections
from kaggle_environments import make
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m.agent
def passer(obs,cfg=None): return {"farmer":["PASS"],"hands":[],"market":[]}
env=make("kaggriculture",configuration={"seed":int(sys.argv[2])}); env.run([load(sys.argv[1],"E"),passer]); st=env.steps
day=int(sys.argv[3])
grid=[["." for _ in range(10)] for _ in range(10)]
f=st[day*24+12][0].observation["farms"][0]
for y in range(10):
    for x in range(10):
        t=f["tiles"][y][x]
        if t=="LOCKED": grid[y][x]="#"
        elif isinstance(t,dict): grid[y][x]=(t.get("crop") or t.get("animal") or t.get("kind"))[0].lower() if t.get("crop") else ((t.get("animal") or t.get("kind"))[0])
work=[["" for _ in range(10)] for _ in range(10)]
labels="0123456789ABCDEF"
for i in range(day*24,day*24+24):
    o=st[i][0].observation["farms"][0]; a=st[i+1][0].action
    pos=[tuple(o["farmer"])]+[tuple(p) for p in o["hands"]]
    acts=[a.get("farmer")]+list(a.get("hands") or [])
    for u,(p,ac) in enumerate(zip(pos,acts)):
        if ac and ac[0] not in ("NORTH","SOUTH","EAST","WEST","PASS","PICKUP","DROP","PLACE"):
            x,y=p
            if labels[u] not in work[y][x]: work[y][x]+=labels[u]
print("day",day,"units",len(pos))
for y in range(10):
    print(" ".join(grid[y][x]+work[y][x].ljust(3) for x in range(10)))
