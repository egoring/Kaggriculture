import importlib.util,sys
from kaggle_environments import make
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m.agent
def passer(obs,cfg=None): return {"farmer":["PASS"],"hands":[],"market":[]}
env=make("kaggriculture",configuration={"seed":int(sys.argv[2])}); env.run([load(sys.argv[1],"E"),passer]); st=env.steps
for d in range(1,29):
    o2=st[d*24+2][0].observation; o23=st[d*24+23][0].observation
    f=o23["farms"][0]; an=[t for row in f["tiles"] for t in row if isinstance(t,dict) and t.get("animal")]
    unfed=[(t["animal"],t["consecutive_unfed"]) for t in an if not t["fed_today"]]
    wheat_inv=sum(i.get("WHEAT",0) for i in o23["private"]["inventories"])
    buys=[o for i in range(d*24,d*24+24) for o in (st[i+1][0].action.get("market") or []) if o[0]=="BUY_PRODUCT"]
    print(f"D{d:2d} money@2 {int(o2['farms'][0]['money']):6d} shedW@2 {o2['private']['shed'].get('WHEAT',0):3d} shedW@23 {o23['private']['shed'].get('WHEAT',0):3d} invW@23 {wheat_inv:2d} animals {len(an):2d} unfed {len(unfed)} {unfed[:4]} buys {buys}")
