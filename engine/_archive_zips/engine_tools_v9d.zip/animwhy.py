import importlib.util,sys,collections
from kaggle_environments import make
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m.agent
def passer(obs,cfg=None): return {"farmer":["PASS"],"hands":[],"market":[]}
tot=collections.Counter()
for sd in [int(x) for x in sys.argv[2].split(",")]:
    env=make("kaggriculture",configuration={"seed":sd}); env.run([load(sys.argv[1],"E"),passer]); st=env.steps
    for d in range(29):
        a_=st[d*24+23][0].observation["farms"][0]["tiles"]; b_=st[d*24+24][0].observation["farms"][0]["tiles"]
        for y in range(10):
            for x in range(10):
                ta,tb=a_[y][x],b_[y][x]
                if isinstance(ta,dict) and ta.get("animal") and isinstance(tb,dict) and tb.get("animal"):
                    k=ta["animal"]; tot[(k,"days")]+=1
                    if not ta["fed_today"]: tot[(k,"unfed")]+=1
                    if not ta["cared_today"]: tot[(k,"uncared")]+=1
                    gain=tb["yield_units"]-ta["yield_units"]
                    if gain>0:
                        tot[(k,"produced")]+=gain; tot[(k,"prod_events")]+=1
                        if tb["yield_units"]>=6: tot[(k,"capped_events")]+=1
                        if not ta["fed_today"]: tot[(k,"prod_unfed")]+=1
                    elif ta.get("pending_care_bonus",0)>0 and tb.get("pending_care_bonus",0)==0 and gain==0: tot[(k,"bonus_lost")]+=1
                    if ta["yield_units"]>=6: tot[(k,"full_days")]+=1
    for i in range(719):
        o=st[i][0].observation["farms"][0]; a=st[i+1][0].action
        pos=[tuple(o["farmer"])]+[tuple(p) for p in o["hands"]]; acts=[a.get("farmer")]+list(a.get("hands") or [])
        for p,ac in zip(pos,acts):
            t=o["tiles"][p[1]][p[0]]
            if ac and ac[0]=="HARVEST" and isinstance(t,dict) and t.get("animal"): tot[(t["animal"],"harvested")]+=t["yield_units"]
n=len(sys.argv[2].split(","))
for k in ("COW","SHEEP","GOOSE"):
    print(k, {m:round(v/n,1) for (a,m),v in sorted(tot.items()) if a==k})
