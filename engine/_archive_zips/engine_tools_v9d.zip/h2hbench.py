import importlib.util,sys,collections,pickle
from kaggle_environments import make
from matrix import mk
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m.agent
A=load(sys.argv[1],"A"); B=mk(pickle.load(open("cols_v9.pkl","rb"))[sys.argv[2]])
env=make("kaggriculture",configuration={"seed":int(sys.argv[3])}); env.run([A,B]); st=env.steps
print("rewards",[s.reward for s in st[-1]])
for day in range(0,29):
    row=[]
    for seat in (0,1):
        t1=day*24+23; f=st[t1][seat].observation["farms"][seat]; pv=st[t1][seat].observation["private"]
        c=collections.Counter()
        for r in f["tiles"]:
            for tl in r:
                if isinstance(tl,dict): c[(tl.get("crop") or tl.get("animal") or tl.get("kind"))[:2]]+=1
        unfed=sum(1 for r in f["tiles"] for tl in r if isinstance(tl,dict) and tl.get("animal") and not tl["fed_today"])
        row.append(f"${int(f['money']):6d} h{len(st[day*24+12][seat].observation['farms'][seat]['hands']):2d} uf{unfed} "+" ".join(f"{k}{v}" for k,v in sorted(c.items())))
    print(f"D{day:2d} | {row[0]:70s} | {row[1]}")
