import importlib.util,sys,collections,pickle
from kaggle_environments import make
from matrix import mk
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m.agent
A=load(sys.argv[1],"A"); B=mk(pickle.load(open("cols_v9.pkl","rb"))[sys.argv[2]])
env=make("kaggriculture",configuration={"seed":int(sys.argv[3])}); env.run([A,B]); st=env.steps
d0,d1=int(sys.argv[4]),int(sys.argv[5])
MOVES={"NORTH","SOUTH","EAST","WEST"}
for seat in (0,1):
    c=collections.Counter(); harv=collections.Counter(); unw=0; plantdays=collections.Counter(); wat=collections.Counter()
    for i in range(d0*24,d1*24):
        o=st[i][seat].observation["farms"][seat]; a=st[i+1][seat].action or {}
        pos=[tuple(o["farmer"])]+[tuple(p) for p in o["hands"]]; acts=[a.get("farmer")]+list(a.get("hands") or [])
        for p,ac in zip(pos,acts):
            if not ac: continue
            k="MOVE" if ac[0] in MOVES else ac[0]; c[k]+=1
            t=o["tiles"][p[1]][p[0]]
            if ac[0]=="HARVEST" and isinstance(t,dict): harv[t.get("crop") or t.get("animal")]+=t.get("yield_units",0)
            if ac[0]=="WATER" and isinstance(t,dict): wat[t.get("crop")]+=1
        if i%24==23:
            for r in o["tiles"]:
                for t in r:
                    if isinstance(t,dict) and t.get("kind")=="PLANT": plantdays[t["crop"]]+=1
    days=d1-d0
    print("seat",seat,"per-day actions",{k:round(v/days,1) for k,v in sorted(c.items())})
    print("   harvested",dict(harv),"plant-days",dict(plantdays),"waters",dict(wat))
