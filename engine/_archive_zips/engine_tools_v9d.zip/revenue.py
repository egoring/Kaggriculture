import importlib.util,sys,collections
from kaggle_environments import make
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m.agent
def passer(obs,cfg=None): return {"farmer":["PASS"],"hands":[],"market":[]}
tot=collections.Counter(); qty=collections.Counter(); n=0
for sd in [int(x) for x in sys.argv[2].split(",")]:
    env=make("kaggriculture",configuration={"seed":sd}); env.run([load(sys.argv[1],"E"),passer]); st=env.steps; n+=1
    for i in range(719):
        m0=st[i][0].observation["farms"][0]["money"]; m1=st[i+1][0].observation["farms"][0]["money"]
        orders=st[i+1][0].action.get("market") or []
        sells=[o for o in orders if o[0]=="SELL"]
        pr=st[i][0].observation["market"]["prices"]
        for o in sells: tot[o[1]]+=pr[o[1]]*int(o[2]); qty[o[1]]+=int(o[2])
print(sys.argv[1], {k:(round(tot[k]/n), round(qty[k]/n), round(tot[k]/max(1,qty[k]))) for k in sorted(tot)}, "total", round(sum(tot.values())/n))
