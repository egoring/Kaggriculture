import importlib.util,sys,collections
from kaggle_environments import make
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m.agent
def passer(obs,cfg=None): return {"farmer":["PASS"],"hands":[],"market":[]}
env=make("kaggriculture",configuration={"seed":int(sys.argv[2])}); env.run([load(sys.argv[1],"E"),passer]); st=env.steps
MOVES={"NORTH","SOUTH","EAST","WEST"}
for day in [int(d) for d in sys.argv[3].split(",")]:
    c=collections.Counter(); per=collections.Counter()
    for i in range(day*24,day*24+24):
        a=st[i+1][0].action; units=[a.get("farmer")]+list(a.get("hands") or [])
        for u,act in enumerate(units):
            if not act: continue
            k="MOVE" if act[0] in MOVES else act[0]; c[k]+=1
            if k not in ("MOVE","PASS"): per[u]+=1
    print("D",day,dict(c),"work/unit",sorted(per.values()))
