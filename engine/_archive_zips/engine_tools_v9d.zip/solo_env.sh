#!/bin/sh
# usage: solo_env.sh <engine> <label> [ENV=val ...]  — 엔진 파일을 스냅샷 복사 후 실행 (편집 오염 방지). SEEDS 환경변수로 시드 지정
f=$1; l=$2; shift 2
mkdir -p snap; cp $f snap/$l.py
S=${SEEDS:-7,17,27,37,47,57,67,77,87,97,107,117,127,137,147,157}
env "$@" python solo2.py snap/$l.py $S >> solo2_$l.log 2>&1
