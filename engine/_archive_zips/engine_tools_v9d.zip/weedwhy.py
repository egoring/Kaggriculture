import importlib.util,sys,collections
from kaggle_environments import make
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m.agent
def passer(obs,cfg=None): return {"farmer":["PASS"],"hands":[],"market":[]}
c=collections.Counter(); plant_hour=collections.Counter()
for sd in [int(x) for x in sys.argv[2].split(",")]:
    env=make("kaggriculture",configuration={"seed":sd}); env.run([load(sys.argv[1],"E"),passer]); st=env.steps
    for d in range(29):
        a_=st[d*24+23][0].observation["farms"][0]["tiles"]; b_=st[d*24+24][0].observation["farms"][0]["tiles"]
        for y in range(10):
            for x in range(10):
                ta,tb=a_[y][x],b_[y][x]
                if isinstance(ta,dict) and ta.get("kind")=="PLANT" and isinstance(tb,dict) and tb.get("kind")=="WEED":
                    c[(ta["crop"],d-ta["planted_day"])]+=1
    for i in range(719):
        a=st[i+1][0].action
        for u in [a.get("farmer")]+list(a.get("hands") or []):
            if u and u[0]=="PLANT": plant_hour[i%24]+=1
print(sorted(c.items(),key=lambda kv:-kv[1])[:15]); print("plant hours",sorted(plant_hour.items()))
