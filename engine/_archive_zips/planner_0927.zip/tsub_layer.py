

# ---------------------------------------------------------------------------
# TSUB (9/27): strawberry -> tomato substitution in tomato worlds. At day 18 hour 0,
# if >= TS_MIN_SHOPS of PIZZA_SHOP/FARMERS_MARKET are unlocked, the K oldest strawberry
# tiles are dug and replanted with tomatoes by the unit the parent tape sends there
# (DIG, PLANT TOMATO, WATER injected; that unit then replays its tape 2 steps late for
# the rest of the day). Later the tape keeps watering them; WATER on a tomato holding
# >= 3 units becomes HARVEST; the tape's DIG on a live tomato is blocked.
import copy as _ts_copy, os as _ts_os
_TS_PARENT = kaggle_submission_agent
_TS_STATES = {}
_TS_MIN_SHOPS = int(_ts_os.environ.get('TS_MIN_SHOPS', '3'))
_TS_K3 = int(_ts_os.environ.get('TS_K3', '8')); _TS_K4 = int(_ts_os.environ.get('TS_K4', '12'))
_TS_MIN_MONEY = int(_ts_os.environ.get('TS_MIN_MONEY', '15000'))
_TS_REPORT = dict(mode=0, targets=0, digs=0, plants=0, waters=0, harvest_subs=0, dig_blocks=0, seeds=0, delayed_steps=0, errors=0)


def kaggle_submission_agent(observation, configuration=None):
    action = _TS_PARENT(observation, configuration)
    try:
        step = int(observation['step']); player = int(observation['player']); day = step // 24; hour = step % 24
        st = _TS_STATES.get(player)
        if st is None or step <= st['last_step']:
            st = {'last_step': step, 'day': -1, 'mode': None, 'targets': [], 'q': {}, 'delay': {}, 'cache': {}, 'seeds_bought': False}
            _TS_STATES[player] = st
        st['last_step'] = step
        if not isinstance(action, dict) or day < 18:
            return action
        farm = observation['farms'][player]; tiles = farm['tiles']
        if st['day'] != day:
            st['day'] = day; st['q'] = {}; st['delay'] = {}; st['cache'] = {}
        if st['mode'] is None:
            shops = list((observation.get('town') or {}).get('unlocked_shops') or [])
            n = sum(s in ('PIZZA_SHOP', 'FARMERS_MARKET') for s in shops)
            k = 0 if n < _TS_MIN_SHOPS else (_TS_K3 if n == 3 else _TS_K4)
            if farm['money'] < _TS_MIN_MONEY: k = 0
            straw = [((x, y), int(t.get('planted_day', 0))) for y, row in enumerate(tiles) for x, t in enumerate(row)
                     if isinstance(t, dict) and t.get('kind') == 'PLANT' and t.get('crop') == 'STRAWBERRY']
            straw.sort(key=lambda v: v[1])
            st['targets'] = [p for p, _ in straw[:k]]; st['mode'] = k > 0
            _TS_REPORT['mode'] = int(k > 0); _TS_REPORT['targets'] = len(st['targets'])
        if not st['mode']:
            return action
        market = list(action.get('market') or [])
        if not st['seeds_bought'] and len(market) < MAX_ORDERS and farm['money'] > 50 * len(st['targets']) + 3000:
            market.append(['BUY_SEED', 'TOMATO', len(st['targets'])]); st['seeds_bought'] = True; _TS_REPORT['seeds'] += len(st['targets'])
        cmds = [action.get('farmer') or ['PASS']] + list(action.get('hands') or [])
        n_units = len(farm['hands']) + 1
        cmds += [['PASS'] for _ in range(n_units - len(cmds))]
        st['cache'][step] = list(cmds)
        positions = [tuple(farm['farmer'])] + [tuple(h) for h in farm['hands']]
        seeds = int(observation['private'].get('seeds', {}).get('TOMATO', 0))
        pending_plants = sum(1 for u in st['q'].values() for c in u if c[0] == 'PLANT')
        tset = set(st['targets'])
        out = list(cmds)
        for u in range(n_units):
            pos = positions[u] if u < len(positions) else None
            if u in st['q'] and st['q'][u]:
                c = st['q'][u].pop(0); out[u] = c; st['delay'][u] = st['delay'].get(u, 0) + 1
                k = {'DIG': 'digs', 'PLANT': 'plants', 'WATER': 'waters'}.get(c[0])
                if k: _TS_REPORT[k] += 1
                continue
            d = st['delay'].get(u, 0)
            if d > 0:
                prev = st['cache'].get(step - d)
                out[u] = list(prev[u]) if prev and u < len(prev) else ['PASS']; _TS_REPORT['delayed_steps'] += 1
                c = out[u]
            else:
                c = out[u]
            if pos is None or pos not in tset: continue
            tile = tiles[pos[1]][pos[0]]
            is_straw = isinstance(tile, dict) and tile.get('kind') == 'PLANT' and tile.get('crop') == 'STRAWBERRY'
            is_tom = isinstance(tile, dict) and tile.get('kind') == 'PLANT' and tile.get('crop') == 'TOMATO'
            if is_straw and c and c[0] in ('WATER', 'FERTILIZE', 'HARVEST') and seeds - pending_plants >= 1 and hour <= 20 and day <= 19 and u not in st['delay']:
                out[u] = ['DIG']; st['q'][u] = [['PLANT', 'TOMATO'], ['WATER']]; st['delay'][u] = 1; pending_plants += 1; _TS_REPORT['digs'] += 1
            elif is_tom:
                if c and c[0] == 'DIG':
                    out[u] = ['PASS']; _TS_REPORT['dig_blocks'] += 1
                elif c and c[0] == 'WATER' and int(tile.get('yield_units', 0)) >= 3:
                    out[u] = ['HARVEST']; _TS_REPORT['harvest_subs'] += 1
                elif c and c[0] == 'WATER' and int(tile.get('yield_units', 0)) > 0 and day >= 28:
                    out[u] = ['HARVEST']; _TS_REPORT['harvest_subs'] += 1
        shed_tom = int(observation['private'].get('shed', {}).get('TOMATO', 0))
        if shed_tom > 0 and len(market) < MAX_ORDERS and not any(o and o[:2] == ['SELL', 'TOMATO'] for o in market):
            market.append(['SELL', 'TOMATO', shed_tom])
        action = _ts_copy.deepcopy(action); action['farmer'] = out[0]; action['hands'] = out[1:]; action['market'] = market
    except Exception:
        _TS_REPORT['errors'] += 1
    return action


kaggle_submission_agent.telemetry = _TS_REPORT
agent = kaggle_submission_agent
