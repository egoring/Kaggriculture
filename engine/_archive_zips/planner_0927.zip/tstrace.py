import importlib.util,sys,pickle
from kaggle_environments import make
from tapeagent import make_tape_agent
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
pool,cand,EP=sys.argv[1],sys.argv[2],int(sys.argv[3])
P=pickle.load(open(f'recs_cache/logs__{pool}__all.pkl','rb'))
d={r['seat']:r for r in P if r['ep']==EP}
me=[r for r in d.values() if r['name']=='weense'][0]; op=[r for r in d.values() if r is not me][0]
ME=load(cand,'ME'); tape=make_tape_agent(op['acts'])
env=make("kaggriculture",configuration={"seed":me['seed']}); env.reset()
cfg=dict(env.configuration); cfg['__raw_path__']='/root/kg/'+cand
sold=0
for t in range(720):
    obs=[env._Environment__get_shared_state(i).observation for i in (0,1)]
    acts=[None,None]; acts[me['seat']]=ME.kaggle_submission_agent(obs[me['seat']],cfg); acts[op['seat']]=tape(obs[op['seat']],env.configuration)
    o=obs[me['seat']]
    for m in acts[me['seat']]['market']:
        if m and m[0]=='SELL' and m[1]=='TOMATO': sold+=min(m[2],o['private']['shed'].get('TOMATO',0))
    if t%24==23 and t//24>=17:
        st=ME._TS_STATES[me['seat']]; f=o['farms'][me['seat']]
        rows=[]
        for (x,y) in st['targets']:
            tl=f['tiles'][y][x]
            rows.append('%s:%s' % ((x,y), (tl['crop'][:3]+'y'+str(tl['yield_units'])+('w' if tl['watered_today'] else '-')+'cu'+str(tl['consecutive_unwatered'])) if isinstance(tl,dict) and tl.get('kind')=='PLANT' else (tl.get('kind') if isinstance(tl,dict) else tl)))
        print(f"d{t//24} money {f['money']:.0f} shed_tom {o['private']['shed'].get('TOMATO',0)} sold_tom {sold} price {o['market']['prices']['TOMATO']} | {' '.join(rows)}")
    env.step(acts)
    if env.done: break
print('FINAL',[s.reward for s in env.state], ME._TS_REPORT)
