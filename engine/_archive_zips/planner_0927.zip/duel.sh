#!/bin/bash
cd /root/kg
out=/root/kg/ev/duel_878_873.txt; : > $out
for s in 7 17 27 37 47; do
  for opp in m2965.py m2965v7.py; do
    for c in submission_v878_v7gasap.py submission_v873_gasap.py; do
      python h2.py $c $opp $s 2>&1 | tail -1 >> $out &
      python h2.py $opp $c $s 2>&1 | tail -1 >> $out &
      wait
    done
  done
done
