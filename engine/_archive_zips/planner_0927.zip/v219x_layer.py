

# ---------------------------------------------------------------------------
# V219X (9/27): second tomato block. When the inherited V219 investment commits
# (>=3 PIZZA/FARMERS shops, SE quadrant bought on day 18), plant ten more tomato
# tiles on rows 7-8 of the SE quadrant and hire the same number of crop workers
# V219 hires each day, driven by V219's own worker routine. Sales ride on V219's
# SELL TOMATO (projected shed). Fertilizer is not used on this block.
import copy as _x_copy
_X_PARENT = kaggle_submission_agent
_X_STATES = {}
_X_TARGETS = [(x, y) for y in (7, 8) for x in range(5, 10)]
_X_REPORT = dict(requests=0, hires=0, confirmed=0, shortfalls=0, plants=0, waters=0, harvests=0, budget_declines=0, slot_declines=0)
_X_MIN_CASH = int(__import__('os').environ.get('X_MIN_CASH', '1500'))


def _x_split(count):
    if count <= 1: return [list(_X_TARGETS)]
    if count == 2: return [_X_TARGETS[:5], _X_TARGETS[5:]]
    return [_X_TARGETS[:4], _X_TARGETS[4:7], _X_TARGETS[7:]]


def kaggle_submission_agent(observation, configuration=None):
    action = _X_PARENT(observation, configuration)
    try:
        step = int(observation['step']); player = int(observation['player']); day = step // 24
        st = _X_STATES.get(player)
        if st is None or step <= st['last_step']:
            st = {'last_step': step, 'day': -1, 'workers': {}, 'last_work': {}, 'seen_plants': set(), 'lost': set(), 'targets': list(_X_TARGETS)}
            _X_STATES[player] = st
        st['last_step'] = step
        v = _V219_STATES.get(player)
        if not v or not v.get('eligible') or day < 18 or not isinstance(action, dict):
            return action
        farm = observation['farms'][player]
        if st['day'] != day:
            st['day'] = day; st['workers'] = {}; st['last_work'] = {}
        pending = st.pop('pending', None)
        if pending:
            if len(farm['hands']) + 1 >= pending['first_actor'] + pending['count'] and 'SE' in farm['unlocked_quadrants']:
                for i, tg in enumerate(_x_split(pending['count'])):
                    st['workers'][pending['first_actor'] + i] = {'kind': 'crop', 'targets': tg, 'needs_fertilizer': False}
                _X_REPORT['confirmed'] += pending['count']
            else:
                _X_REPORT['shortfalls'] += pending['count']
        hour = step % 24
        vp = v.get('pending')
        if vp and vp.get('step') == step and v.get('committed'):
            st['vp_day'] = day; st['vp_first'] = int(vp['first_actor']) + int(vp['count']); st['vp_workers'] = int(vp.get('crop_workers', 1)) or 1
        market = list(action.get('market') or [])
        extra = []
        if day == 18 and v.get('committed') and not st.get('seeds_day') and len(market) + 1 <= MAX_ORDERS and hour <= 12:
            extra.append(['BUY_SEED', 'TOMATO', 10]); st['seeds_day'] = day
        if st.get('vp_day') == day and st.get('requested_day') != day and hour <= 8 and 'pending' not in st:
            count = st['vp_workers']
            if len(market) + len(extra) + count <= MAX_ORDERS:
                h0 = int(farm.get('hires_today', 0)) + sum(1 for o in market if o and o[0] == 'HIRE')
                cost = sum(_v219_fib(n) for n in range(h0, h0 + count)) + 500 * len(extra)
                for o in market:
                    if not o: continue
                    if o[0] == 'BUY_PRODUCT': cost += int(o[2]) * (int(observation['market']['prices'][o[1]]) + 10)
                    elif o[0] == 'BUY_ANIMAL': cost += int(o[2]) * {'COW': 400, 'SHEEP': 500, 'GOOSE': 300}[o[1]]
                    elif o[0] == 'BUY_SEED': cost += int(o[2]) * {'WHEAT': 10, 'CARROT': 20, 'TOMATO': 50, 'STRAWBERRY': 100, 'MELON': 80}[o[1]]
                    elif o[0] == 'BUY_LAND': cost += 4000
                if farm['money'] < cost + _X_MIN_CASH:
                    _X_REPORT['budget_declines'] += 1
                else:
                    extra += [['HIRE'] for _ in range(count)]
                    st['pending'] = {'step': step, 'first_actor': st['vp_first'], 'count': count}
                    st['requested_day'] = day; _X_REPORT['requests'] += 1; _X_REPORT['hires'] += count
            else:
                _X_REPORT['slot_declines'] += 1
        if extra:
            action = _x_copy.deepcopy(action); action['market'] = market + extra
        if st['workers']:
            commands = [action.get('farmer') or ['PASS']] + list(action.get('hands') or [])
            commands += [['PASS'] for _ in range(len(farm['hands']) + 1 - len(commands))]
            for actor, role in st['workers'].items():
                if actor >= len(commands): continue
                command = _v219_worker(observation, st, actor, role)
                commands[actor] = command
                k = {'PLANT': 'plants', 'WATER': 'waters', 'HARVEST': 'harvests'}.get(command[0])
                if k: _X_REPORT[k] += 1
                st['last_work'][actor] = {'step': step, 'command': command, 'tomatoes': observation['private']['inventories'][actor].get('TOMATO', 0) if actor < len(observation['private']['inventories']) else 0}
            action = _x_copy.deepcopy(action); action['farmer'], action['hands'] = commands[0], commands[1:]
    except Exception:
        _X_REPORT['errors'] = _X_REPORT.get('errors', 0) + 1
    return action


kaggle_submission_agent.telemetry = _X_REPORT
agent = kaggle_submission_agent
