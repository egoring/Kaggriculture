import sys,importlib.util,collections
from kaggle_environments import make
def load(p):
    s=importlib.util.spec_from_file_location('C'+str(abs(hash(p))),p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
A=load(sys.argv[1]); B=load(sys.argv[2]); seed=int(sys.argv[3]); crop=sys.argv[4] if len(sys.argv)>4 else 'STRAWBERRY'
a=A.kaggle_submission_agent; b=getattr(B,'kaggle_submission_agent',None) or B.agent
env=make("kaggriculture",configuration={"seed":seed}); env.reset()
first={'STRAWBERRY':10,'TOMATO':8}[crop]; interval={'STRAWBERRY':2,'TOMATO':1}[crop]
for t in range(720):
    obs=[env._Environment__get_shared_state(i).observation for i in (0,1)]
    acts=[a(obs[0],env.configuration), b(obs[1],env.configuration)]
    if t%24==23:
        day=t//24; c=collections.Counter(); n=0
        shed=obs[0]['private']['shed']
        for row in obs[0]['farms'][0]['tiles']:
            for tl in row:
                if isinstance(tl,dict) and tl.get('kind')=='PLANT' and tl['crop']==crop:
                    n+=1; age=day-tl['planted_day']; k=age+1-first
                    if k>=0 and k%interval==0 and k//interval<4:
                        c['prod']+=1; c['fert']+= tl.get('fertilized_until_day',-1)>=day; c['wat']+=tl['watered_today']
                        c['both']+= (tl.get('fertilized_until_day',-1)>=day and tl['watered_today'])
                    if not tl['watered_today'] and tl['consecutive_unwatered']>=1: c['dying']+=1
                    if tl['yield_units']>=3: c['full']+=1
        if n: print(f"d{day:2d} {crop[:3]} n={n} {dict(c)} shedfert={shed.get('FERTILIZER',0)} money={obs[0]['farms'][0]['money']:.0f}")
    env.step(acts)
    if env.done: break
