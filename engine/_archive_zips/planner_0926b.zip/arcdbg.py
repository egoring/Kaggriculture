import sys,importlib.util
from kaggle_environments import make
def load(p):
    s=importlib.util.spec_from_file_location('C'+str(abs(hash(p))),p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
A=load(sys.argv[1]); B=load(sys.argv[2]); seed=int(sys.argv[3])
a=A.kaggle_submission_agent; b=getattr(B,'kaggle_submission_agent',None) or B.agent
env=make("kaggriculture",configuration={"seed":seed}); env.reset()
for t in range(720):
    obs=[env._Environment__get_shared_state(i).observation for i in (0,1)]
    acts=[a(obs[0],env.configuration), b(obs[1],env.configuration)]
    st=A._STATE[0]
    if t%24==2 and t//24 in (8,12,15,18,21):
        lens=[]
        for sc in st.scripts:
            ops=sum(len(it[2]) for it in sc if it[0]=='VISIT'); tiles=[it[1] for it in sc if it[0]=='VISIT']
            trav=sum(abs(tiles[i][0]-tiles[i-1][0])+abs(tiles[i][1]-tiles[i-1][1]) for i in range(1,len(tiles))) + (abs(tiles[0][0]-4)+abs(tiles[0][1]-4) if tiles else 0)
            lens.append((len(tiles),ops,trav))
        print(f"d{t//24} units {len(st.units)} arcs (tiles,ops,travel): {lens}")
    if t%24==23 and t//24 in (8,12,15,18,21):
        st.parse(obs[0])
        pend=[(p,st.tile_todo(p)) for p,_ in st.plants+st.animals if st.tile_todo(p)]
        print(f"   d{t//24} h23 pending tiles {len(pend)} e.g. {pend[:5]}; unit pos {st.units[:4]} scriptpos {st.script_pos[:6]} lens {[len(s) for s in st.scripts[:6]]}")
    env.step(acts)
    if env.done: break
