import sys,importlib.util
from kaggle_environments import make
def load(p):
    s=importlib.util.spec_from_file_location('C'+str(abs(hash(p))),p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
A=load(sys.argv[1]); B=load(sys.argv[2]); seed=int(sys.argv[3])
a=A.kaggle_submission_agent; b=getattr(B,'kaggle_submission_agent',None) or B.agent
env=make("kaggriculture",configuration={"seed":seed}); env.reset()
for t in range(720):
    obs=[env._Environment__get_shared_state(i).observation for i in (0,1)]
    if t%48==0:
        m=obs[0]['market']; print(f"d{t//24:2d}", {k[:4]:v for k,v in m['prices'].items()}, 'inv', {k[:4]:v-10000 for k,v in m['inventory'].items()}, obs[0]['town']['unlocked_shops'])
    env.step([a(obs[0],env.configuration), b(obs[1],env.configuration)])
    if env.done: break
