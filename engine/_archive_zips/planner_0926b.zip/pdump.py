import sys,importlib.util,collections
from kaggle_environments import make
def load(p):
    s=importlib.util.spec_from_file_location('C'+str(abs(hash(p))),p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
A=load(sys.argv[1]); B=load(sys.argv[2]); seed=int(sys.argv[3]); seat=int(sys.argv[4]) if len(sys.argv)>4 else 0
a=A.kaggle_submission_agent; b=getattr(B,'kaggle_submission_agent',None) or B.agent
env=make("kaggriculture",configuration={"seed":seed}); env.reset()
ops=collections.Counter(); sold=collections.Counter(); hires=0; rev=0
for t in range(720):
    obs=[env._Environment__get_shared_state(i).observation for i in (0,1)]
    acts=[None,None]; acts[seat]=a(obs[seat],env.configuration); acts[1-seat]=b(obs[1-seat],env.configuration)
    aa=acts[seat]; f=obs[0]['farms'][seat]
    hires+=sum(1 for o in aa['market'] if o and o[0]=='HIRE')
    for o in aa['market']:
        if o and o[0]=='SELL': sold[o[1]]+=min(o[2],obs[seat]['private']['shed'].get(o[1],0))
    for c in [aa['farmer']]+aa['hands']: ops[c[0]]+=1
    if t%24==23:
        an=collections.Counter(); pl=collections.Counter(); weeds=0; unw=0
        for row in f['tiles']:
            for tl in row:
                if isinstance(tl,dict):
                    if 'animal' in tl: an[tl['animal'][:3]]+=1
                    elif tl.get('kind')=='PLANT': pl[tl['crop'][:3]]+=1; unw+= (not tl['watered_today'])
                    elif tl.get('kind')=='WEED': weeds+=1
        mv=sum(v for k,v in ops.items() if k in ('NORTH','SOUTH','EAST','WEST'))
        print(f"d{t//24:2d} $ {f['money']:6.0f} (opp {obs[0]['farms'][1-seat]['money']:6.0f}) u{hires+1:2d} q{len(f['unlocked_quadrants'])} an {dict(an)} pl {dict(pl)} unw {unw} weeds {weeds} | sold {dict(sold)} | ops {dict((k[:4],v) for k,v in ops.items() if k in ('WATER','HARVEST','FEED','CARE','COLLECT_FERTILIZER','FERTILIZE','PLANT','PASS','DROP'))} mv {mv} shops {len(obs[0]['town']['unlocked_shops'])}",flush=True)
        ops=collections.Counter(); sold=collections.Counter(); hires=0
    env.step(acts)
    if env.done: break
rw=[s.reward for s in env.state]; print('FINAL',rw,'margin %+.0f'%(rw[seat]-rw[1-seat]))
