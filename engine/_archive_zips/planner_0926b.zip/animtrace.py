import sys,importlib.util,collections
from kaggle_environments import make
def load(p):
    s=importlib.util.spec_from_file_location('C'+str(abs(hash(p))),p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
A=load(sys.argv[1]); B=load(sys.argv[2]); seed=int(sys.argv[3])
ag=[A.kaggle_submission_agent, getattr(B,'kaggle_submission_agent',None) or B.agent]
env=make("kaggriculture",configuration={"seed":seed}); env.reset()
buys=collections.Counter(); esc=0; prev=None
for t in range(720):
    obs=[env._Environment__get_shared_state(i).observation for i in (0,1)]
    acts=[ag[i](obs[i],env.configuration) for i in (0,1)]
    for o in acts[0]['market']:
        if o[0]=='BUY_ANIMAL': buys[o[1]]+=o[2]
    f=obs[0]['farms'][0]
    cur={}
    for y,row in enumerate(f['tiles']):
        for x,tl in enumerate(row):
            if isinstance(tl,dict) and 'animal' in tl: cur[(x,y)]=(tl['animal'],tl['consecutive_unfed'],tl['fed_today'])
    if prev is not None:
        for p,v in prev.items():
            if p not in cur:
                esc+=1; print(f"step {t} day {t//24} h{t%24} animal gone at {p}: {v}")
    prev=cur
    if t%24==23:
        pv=obs[0]['private']; inv=collections.Counter()
        for iv in pv['inventories']:
            for k in ('COW','SHEEP','GOOSE'): inv[k]+=iv.get(k,0)
        print(f"d{t//24} tiles {collections.Counter(v[0] for v in cur.values())} shed {{k:pv['shed'].get(k,0) for k in ('COW','SHEEP','GOOSE')}} inv {dict(inv)} buys {dict(buys)} unfed_now {sum(1 for v in cur.values() if not v[2])}")
    env.step(acts)
    if env.done: break
