import sys,importlib.util
from kaggle_environments import make
def load(p):
    s=importlib.util.spec_from_file_location('C'+str(abs(hash(p))),p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
A=load(sys.argv[1]); B=load(sys.argv[2]); seed=int(sys.argv[3])
a=A.kaggle_submission_agent; b=getattr(B,'kaggle_submission_agent',None) or B.agent
env=make("kaggriculture",configuration={"seed":seed}); env.reset()
for t in range(720):
    obs=[env._Environment__get_shared_state(i).observation for i in (0,1)]
    acts=[a(obs[0],env.configuration), b(obs[1],env.configuration)]
    st=A._STATE[0]
    if t%24==1:
        led=st.ledger_existing()
        vals={c:(round(v[0]) if v else None) for c,v in ((c,st.crop_value(c,led,st.day)) for c in A.CROPS)}
        av={k:(round(v[0]) if v else None) for k,v in ((k,st.animal_value(k,led,st.day)) for k in A.ANIMALS)}
        print(f"d{st.day:2d} $ {st.money:6.0f} empties {len(st.empty)} plan {st.plan_log[:6]}.. n={len(st.plan_log)} vals {vals} anim {av} hold {st.hold} tg {st.targets} opp {{k[:3]:round(v,1) for k,v in st.mm.opp_rate.items()}}")
    if t%24==23:
        crit=sum(1 for _,tl in st.plants if int(tl.get('consecutive_unwatered',0))>=1 and not tl['watered_today'])
        unfed=sum(1 for _,tl in st.animals if not tl['fed_today'])
        if crit or unfed: print(f"   d{st.day} crit-unwatered {crit} unfed {unfed} units {len(st.units)}")
    env.step(acts)
    if env.done: break
print('FINAL',[s.reward for s in env.state])
