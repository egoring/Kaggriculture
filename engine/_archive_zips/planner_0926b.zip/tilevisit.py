import sys,importlib.util
from kaggle_environments import make
def load(p):
    s=importlib.util.spec_from_file_location('C'+str(abs(hash(p))),p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
A=load(sys.argv[1]); B=load(sys.argv[2]); seed=int(sys.argv[3]); D=int(sys.argv[4]); X=int(sys.argv[5]); Y=int(sys.argv[6])
ag=[A.kaggle_submission_agent, getattr(B,'kaggle_submission_agent',None) or B.agent]
env=make("kaggriculture",configuration={"seed":seed}); env.reset()
for t in range(720):
    obs=[env._Environment__get_shared_state(i).observation for i in (0,1)]
    acts=[ag[i](obs[i],env.configuration) for i in (0,1)]
    st=A._STATE[0]
    if t//24==D:
        if t%24==2:
            for i,sc in enumerate(st.scripts):
                for it in sc:
                    if it[0]=='VISIT' and it[1]==(X,Y): print('unit',i,'script',sc)
        f=obs[0]['farms'][0]; units=[tuple(f['farmer'])]+[tuple(h) for h in f['hands']]
        tl=f['tiles'][Y][X]
        here=[(i,a) for i,(u,a) in enumerate(zip(units,[acts[0]['farmer']]+acts[0]['hands'])) if u==(X,Y)]
        print(f"h{t%24:2d} tile {tl if not isinstance(tl,dict) else {k:tl[k] for k in tl if k in ('animal','fed_today','cared_today','yield_units','kind')}} units_here {here} shedwheat {obs[0]['private']['shed'].get('WHEAT',0)} invs {[iv.get('WHEAT',0) for iv in obs[0]['private']['inventories']]}")
    env.step(acts)
    if env.done: break
