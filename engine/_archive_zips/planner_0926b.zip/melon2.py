import sys,importlib.util
from kaggle_environments import make
def load(p):
    s=importlib.util.spec_from_file_location('C'+str(abs(hash(p))),p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
A=load(sys.argv[1]); B=load(sys.argv[2]); seed=int(sys.argv[3])
ag=[A.kaggle_submission_agent, getattr(B,'kaggle_submission_agent',None) or B.agent]
env=make("kaggriculture",configuration={"seed":seed}); env.reset()
pinv=None; pm=None
for t in range(24*12):
    obs=[env._Environment__get_shared_state(i).observation for i in (0,1)]
    inv=obs[0]['market']['inventory']['MELON']; m=[obs[0]['farms'][i]['money'] for i in (0,1)]
    if pinv is not None and inv!=pinv and t>=240:
        print(f"step {t-1} d{(t-1)//24} h{(t-1)%24} melon inv +{inv-pinv} price_now {obs[0]['market']['prices']['MELON']} money delta p0 {m[0]-pm[0]:+.0f} p1 {m[1]-pm[1]:+.0f}")
    pinv=inv; pm=m
    acts=[ag[i](obs[i],env.configuration) for i in (0,1)]
    env.step(acts)
