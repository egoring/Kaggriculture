import sys,collections,importlib.util
from kaggle_environments import make
def load(p):
    s=importlib.util.spec_from_file_location('C'+str(abs(hash(p))),p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return getattr(m,'kaggle_submission_agent',None) or m.agent
A,B,seed=sys.argv[1],sys.argv[2],int(sys.argv[3])
env=make("kaggriculture",configuration={"seed":seed}); env.reset()
G=env.interpreter.__globals__; orig=G['_commit_unit']
REV=[collections.Counter(),collections.Counter()]; QTY=[collections.Counter(),collections.Counter()]; HARV=[collections.Counter(),collections.Counter()]
CUR={'farms':None}
def hook(op,item,price,farm,private,market,shed_capacity=100):
    ok=orig(op,item,price,farm,private,market,shed_capacity)
    if ok:
        pid=0 if farm is CUR['farms'][0] else 1
        REV[pid][op+':'+item]+= price if op=='SELL' else -price; QTY[pid][op+':'+item]+=1
    return ok
G['_commit_unit']=hook
oa=G['_apply_unit_action']
def ha(farm, private, idx, action, board_size, day, turns_per_day, shed_capacity=100):
    if isinstance(action,list) and action and action[0]=='HARVEST':
        pos=G['_farmer_position'](farm,idx); t=farm['tiles'][pos[1]][pos[0]]
        if isinstance(t,dict):
            pid=0 if farm is CUR['farms'][0] else 1
            HARV[pid][t.get('crop') or t.get('animal')]+=t.get('yield_units',0)
    return oa(farm, private, idx, action, board_size, day, turns_per_day, shed_capacity)
G['_apply_unit_action']=ha
oi=env.interpreter
def interp(state, env_):
    CUR['farms']=list(state[0].observation.farms); return oi(state, env_)
env.interpreter=interp
a=load(A); b=load(B); hires=[0,0]
for t in range(720):
    obs=[env._Environment__get_shared_state(i).observation for i in (0,1)]
    acts=[a(obs[0],env.configuration),b(obs[1],env.configuration)]
    for i in (0,1): hires[i]+=sum(1 for o in (acts[i].get('market') or []) if o and o[0]=='HIRE')
    env.step(acts)
    if env.done: break
rw=[s.reward for s in env.state]; print(A,'vs',B,'seed',seed,'final',rw,'hires',hires)
keys=sorted(set(REV[0])|set(REV[1]))
print(f"{'':22s} {'A $':>8s} {'A n':>5s} {'B $':>8s} {'B n':>5s}")
for k in keys: print(f"  {k:20s} {REV[0][k]:8.0f} {QTY[0][k]:5d} {REV[1][k]:8.0f} {QTY[1][k]:5d}")
print('harvested A',dict(HARV[0])); print('harvested B',dict(HARV[1]))
