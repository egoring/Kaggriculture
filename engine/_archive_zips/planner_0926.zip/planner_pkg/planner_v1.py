# kaggriculture planner v1 (9/26) — self-written farm planner, no recorded routes.
# Economy thesis (from env source): animals give 1 FERTILIZER/day each plus product; EGG/WHEAT markets are
# log-deep (egg >= $37 even at I0+1500), MILK/WOOL/STRAWBERRY/MELON collapse within 60-160 units above I0.
# So: geese-first (300 each, first egg day 4, 2 eggs/day with CARE), wheat bought from the market for feed,
# everything sold the step it lands in the shed, high-value shallow markets used only up to their draw rate.
import math

# ---------------- parameters ----------------
P = dict(
    hands_per_day=13,          # hires at hour 0 (fib cost: 10 hands = $142/day)
    max_hands=14,
    wheat_reserve_days=1,      # wheat kept in shed = animals * days
    goose_cap=30,
    wheat_tiles=20,           # tiles kept for wheat (feed) once NE is bought              # total geese target
    cow_cap=0, sheep_cap=0,
    land_buffer=600,           # buy next quadrant when money > price + buffer and free tiles < 4
    melon_tiles=0,             # v1: no crops (pure animal economy) — crops come in v2
    fert_sell_floor=12,        # sell fertilizer while price >= this, otherwise keep (v2 uses it)
    inv_drop_at=6,            # hand returns to shed when carrying >= this many product units
)
ANIMALS = {"GOOSE": dict(cost=300, structure="COOP", first=4, interval=1, product="EGG"),
           "COW": dict(cost=400, structure="PASTURE", first=8, interval=2, product="MILK"),
           "SHEEP": dict(cost=500, structure="PASTURE", first=6, interval=3, product="WOOL")}
PRODUCTS = ["WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL", "FERTILIZER"]
SHED_TILES = [(4, 4), (5, 4), (4, 5), (5, 5)]
QUAD = {"NW": (0, 0), "NE": (5, 0), "SW": (0, 5), "SE": (5, 5)}

_STATE = {}


def _quadrant(x, y):
    return ("N" if y < 5 else "S") + ("W" if x < 5 else "E")


def _dist(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def _step_toward(pos, tgt):
    dx, dy = tgt[0] - pos[0], tgt[1] - pos[1]
    if abs(dx) >= abs(dy) and dx != 0:
        return ["EAST"] if dx > 0 else ["WEST"]
    if dy != 0:
        return ["SOUTH"] if dy > 0 else ["NORTH"]
    return ["PASS"]


def _nearest_shed(pos):
    return min(SHED_TILES, key=lambda t: _dist(pos, t))


class Planner:
    def __init__(self, player):
        self.player = player
        self.day_planned = -1
        self.pending_orders = []
        self.log = []

    # ---------- observation parsing ----------
    def parse(self, obs):
        self.obs = obs
        self.step = int(obs["step"]); self.day = self.step // 24; self.hour = self.step % 24
        farm = obs["farms"][self.player]
        self.farm = farm; self.money = float(farm["money"]); self.tiles = farm["tiles"]
        self.private = obs["private"]; self.shed = dict(self.private.get("shed") or {})
        self.seeds = dict(self.private.get("seeds") or {})
        self.invs = [dict(x) for x in (self.private.get("inventories") or [{}])]
        self.units = [tuple(farm["farmer"])] + [tuple(h) for h in farm["hands"]]
        while len(self.invs) < len(self.units):
            self.invs.append({})
        self.market = obs["market"]; self.prices = dict(self.market.get("prices") or {})
        self.quads = list(farm.get("unlocked_quadrants") or ["NW"])
        # tile lists
        self.animals = []; self.empty = []; self.weeds = []; self.plants = []; self.structs = []
        for y in range(10):
            for x in range(10):
                t = self.tiles[y][x]
                if t == "LOCKED":
                    continue
                if t is None:
                    self.empty.append((x, y))
                elif isinstance(t, dict):
                    if "animal" in t:
                        self.animals.append(((x, y), t))
                    elif t.get("kind") == "PLANT":
                        self.plants.append(((x, y), t))
                    elif t.get("kind") == "WEED":
                        self.weeds.append((x, y))
                    elif t.get("kind") in ("COOP", "PASTURE"):
                        self.structs.append(((x, y), t["kind"]))

    # ---------- daily / market planning ----------
    def market_orders(self):
        orders = []
        n_units = len(self.units)
        # 1) hires at hour 0
        if self.hour == 0:
            want = min(P["hands_per_day"], P["max_hands"])
            # scale hands with work: ~1 hand per 4 animals + 2
            want = max(3, min(want, math.ceil(self.animals_total() / 2) + 2))
            orders += [["HIRE"]] * want
        # 2) sell everything that landed (all products except wheat reserve; fertilizer above floor price)
        reserve = self.animals_total() * P["wheat_reserve_days"]
        sells = []
        for item in PRODUCTS:
            q = int(self.shed.get(item, 0))
            if item == "WHEAT":
                q = q - (0 if self.step >= 716 else reserve)
            if item == "FERTILIZER" and int(self.prices.get(item, 0)) < P["fert_sell_floor"] and self.step < 716 and sum(self.shed.values()) < 60:
                q = 0
            if q > 0:
                sells.append(["SELL", item, q])
        # most valuable first (slot 0 executes first in lockstep)
        sells.sort(key=lambda o: -int(self.prices.get(o[1], 0)) * o[2])
        orders += sells
        # 3) purchases
        money = self.money + sum(int(self.prices.get(o[1], 0)) * o[2] for o in sells) * 0.9
        # wheat for feed
        need_wheat = reserve + 2 - int(self.shed.get("WHEAT", 0))
        if need_wheat > 0 and money > 200:
            q = min(need_wheat, 40, int((money - 100) // max(1, int(self.prices.get("WHEAT", 25)) + 2)))
            if q > 0:
                orders.append(["BUY_PRODUCT", "WHEAT", q]); money -= q * (int(self.prices.get("WHEAT", 25)) + 2)
        # keep cash for tomorrow's feed (wheat ~ $30/animal) before any investment
        feed_reserve = 30 * self.animals_total() + 100
        money -= feed_reserve
        # wheat seeds for empty tiles (planting is done by idle units)
        if self.hour == 0 and self.day <= 24:
            plantable = max(0, len(self.empty) - self.animals_in_shed() - self.animals_carried() - 2)
            want_seeds = min(plantable, P["wheat_tiles"]) - int(self.seeds.get("WHEAT", 0))
            if want_seeds > 0 and money > 10 * want_seeds + 100:
                orders.append(["BUY_SEED", "WHEAT", want_seeds]); money -= 10 * want_seeds
        # land
        free_now = len(self.empty)
        for i, qn in enumerate(["NE", "SW", "SE"]):
            if qn in self.quads:
                continue
            price = [1000, 2000, 4000][i]
            if free_now < 4 and money > price + P["land_buffer"] and self.day <= 20:
                orders.append(["BUY_LAND"]); money -= price
            break
        # animals: geese first, then a few cows/sheep; only if there is a free tile (structure or empty) for them
        cnt = self.animal_counts()
        placeable = len([1 for _, k in self.structs]) + len(self.empty)
        in_shed = self.animals_in_shed() + self.animals_carried()
        room = placeable - in_shed
        labour_cap = 4 * (min(P["hands_per_day"], P["max_hands"]) + 1)
        for kind, cap in (("GOOSE", min(P["goose_cap"], labour_cap)), ("COW", P["cow_cap"]), ("SHEEP", P["sheep_cap"])):
            if self.day > 16 or len(self.units) < 4:
                break
            have = cnt.get(kind, 0) + int(self.shed.get(kind, 0)) + sum(int(inv.get(kind, 0)) for inv in self.invs)
            n = 0
            while have + n < cap and room > 0 and money > ANIMALS[kind]["cost"] + 30 * (n + 1) and n < 6:
                n += 1; room -= 1; money -= ANIMALS[kind]["cost"] + 30
            if n > 0:
                orders.append(["BUY_ANIMAL", kind, n])
        return orders[:10]

    def animal_counts(self):
        c = {}
        for _, t in self.animals:
            c[t["animal"]] = c.get(t["animal"], 0) + 1
        return c

    def animals_in_shed(self):
        return sum(int(self.shed.get(k, 0)) for k in ANIMALS)

    def animals_carried(self):
        return sum(int(inv.get(k, 0)) for inv in self.invs for k in ANIMALS)

    def animals_total(self):
        return len(self.animals) + self.animals_in_shed() + self.animals_carried()

    # ---------- day scripts ----------
    def make_day_scripts(self):
        """At the first step the day's hands exist (hour 1): split the animals into circuits, one per unit."""
        n = len(self.units)
        anim = [pos for pos, t in self.animals]
        per = max(1, math.ceil(len(anim) / max(1, n)))
        chunks = [[] for _ in range(n)]
        left = list(anim)
        # farmer + hands pick their nearest animals in turn (round-robin) so circuits stay compact
        cur = [self.units[i] for i in range(n)]
        for r in range(per):
            for i in range(n):
                if not left:
                    break
                p = min(left, key=lambda q: _dist(cur[i], q)); left.remove(p); chunks[i].append(p); cur[i] = p
        # shortest tour order inside each chunk (nearest neighbour from the unit position)
        for i in range(n):
            pts = chunks[i]; order = []; c = self.units[i]
            while pts:
                p = min(pts, key=lambda q: _dist(c, q)); pts.remove(p); order.append(p); c = p
            chunks[i] = order
        self.scripts = []
        for i in range(n):
            sc = []
            if chunks[i]:
                sc.append(("PICKUP_WHEAT", len(chunks[i])))
                for p in chunks[i]:
                    sc.append(("VISIT", p))
                sc.append(("DROP",))
            self.scripts.append(sc)
        self.script_pos = [0] * n
        self.script_day = self.day

    def build_jobs(self):
        jobs = []
        for pos, t in self.plants:
            if not t["watered_today"]:
                jobs.append((90 + 40 * int(t.get("consecutive_unwatered", 0)), pos, ("WATER",)))
            age = self.day - int(t.get("planted_day", self.day))
            if t.get("yield_units", 0) > 0 and (t.get("yield_units", 0) >= 4 or (age >= 4 and t["watered_today"]) or age >= 5):
                jobs.append((70, pos, ("HARVEST",)))
        # plant wheat on empty tiles not needed for animals waiting to be placed
        reserve_tiles = self.animals_in_shed() + self.animals_carried()
        seeds = int(self.seeds.get("WHEAT", 0))
        if seeds > 0 and self.day <= 24:
            cands = sorted(self.empty, key=lambda p: -_dist(p, (4, 4)))  # farthest from shed first (animals stay close)
            for pos in cands[:max(0, min(seeds, len(cands) - reserve_tiles))]:
                jobs.append((50, pos, ("PLANT", "WHEAT")))
        for pos in self.weeds:
            jobs.append((10, pos, ("DIG",)))
        return jobs

    def visit_op(self, pos, wheat):
        """Next useful op on the animal tile at pos, or None when the visit is complete."""
        t = self.tiles[pos[1]][pos[0]]
        if not (isinstance(t, dict) and "animal" in t):
            return None
        if not t["fed_today"] and wheat > 0:
            return ["FEED"]
        if not t["cared_today"]:
            return ["CARE"]
        if t.get("fertilizer_available"):
            return ["COLLECT_FERTILIZER"]
        if t.get("yield_units", 0) > 0:
            return ["HARVEST"]
        return None

    def assign(self, jobs):
        n = len(self.units)
        if self.hour == 0:
            self.scripts = [[] for _ in range(n)]; self.script_pos = [0] * n; self.script_day = -1
        elif getattr(self, "script_day", -1) != self.day or len(getattr(self, "scripts", [])) != n:
            self.make_day_scripts()
        acts = [None] * n
        taken = set()
        wheat = [int(inv.get("WHEAT", 0)) for inv in self.invs]
        carry = [sum(v for k, v in inv.items() if k in PRODUCTS and k != "WHEAT") for inv in self.invs]
        animals_carried = [{k: int(inv.get(k, 0)) for k in ANIMALS if inv.get(k, 0)} for inv in self.invs]
        shed_wheat = int(self.shed.get("WHEAT", 0))
        last_day = self.day >= 29
        for i in range(n):
            pos = self.units[i]; sh = _nearest_shed(pos); dsh = _dist(pos, sh)
            # a) carrying an animal: place it (build a structure if none is free)
            if animals_carried[i]:
                kind = next(iter(animals_carried[i])); st = ANIMALS[kind]["structure"]
                free_structs = [p for p, k in self.structs if k == st and p not in taken]
                if free_structs:
                    tgt = min(free_structs, key=lambda p: _dist(pos, p)); taken.add(tgt)
                    acts[i] = ["PLACE", kind] if pos == tgt else _step_toward(pos, tgt)
                    continue
                empties = [p for p in self.empty if p not in taken]
                if empties:
                    tgt = min(empties, key=lambda p: (_dist(p, (4, 4)), _dist(pos, p))); taken.add(tgt)
                    acts[i] = ["BUILD_" + st] if pos == tgt else _step_toward(pos, tgt)
                    continue
            # b) follow the day script
            sc = self.scripts[i]; k = self.script_pos[i]
            done = False
            while k < len(sc) and acts[i] is None:
                item = sc[k]
                if item[0] == "PICKUP_WHEAT":
                    need = min(item[1], shed_wheat)
                    if wheat[i] >= item[1] or need <= 0:
                        k += 1; continue
                    if dsh == 0:
                        acts[i] = ["PICKUP", "WHEAT", need]; shed_wheat -= need; k += 1
                    else:
                        acts[i] = _step_toward(pos, sh)
                elif item[0] == "VISIT":
                    tgt = item[1]
                    if pos != tgt:
                        acts[i] = _step_toward(pos, tgt)
                    else:
                        op = self.visit_op(tgt, wheat[i])
                        if op is None:
                            k += 1; continue
                        acts[i] = op
                        if op[0] == "FEED":
                            wheat[i] -= 1
                elif item[0] == "DROP":
                    if carry[i] <= 0 and wheat[i] <= 0:
                        k += 1; continue
                    if dsh == 0:
                        acts[i] = ["DROP"]; k += 1
                    else:
                        acts[i] = _step_toward(pos, sh)
                else:
                    k += 1
            self.script_pos[i] = k
            if acts[i] is not None:
                continue
            # c) script finished: extra work — fetch animals waiting in the shed, plant/water jobs, weeds
            if self.animals_in_shed() > 0 and not last_day:
                if dsh == 0:
                    kind = next(kk for kk in ANIMALS if int(self.shed.get(kk, 0)) > 0)
                    q = min(int(self.shed.get(kind, 0)), 2)
                    acts[i] = ["PICKUP", kind, q]; self.shed[kind] = int(self.shed.get(kind, 0)) - q
                else:
                    acts[i] = _step_toward(pos, sh)
                continue
            if carry[i] > 0 and (self.hour >= 21 or carry[i] >= 8):
                acts[i] = ["DROP"] if dsh == 0 else _step_toward(pos, sh)
                continue
            best = None; bestv = -1e9
            for j in jobs:
                pr, tile, op = j
                if tile in taken:
                    continue
                v = pr - 6 * _dist(pos, tile)
                if v > bestv:
                    bestv = v; best = j
            if best is None:
                acts[i] = ["DROP"] if (dsh == 0 and carry[i] > 0) else ["PASS"]
                continue
            pr, tile, op = best; taken.add(tile)
            acts[i] = list(op) if pos == tile else _step_toward(pos, tile)
        return acts

    def act(self, obs):
        self.parse(obs)
        jobs = self.build_jobs()
        acts = self.assign(jobs)
        # goods dropped this step are in the shed when the market runs: sell them in the same step
        for i, a in enumerate(acts):
            if a and a[0] == "DROP" and self.units[i] in SHED_TILES:
                for k, v in self.invs[i].items():
                    self.shed[k] = int(self.shed.get(k, 0)) + int(v)
        market = self.market_orders()
        return {"farmer": acts[0], "hands": acts[1:], "market": market}


def kaggle_submission_agent(observation, configuration=None):
    player = int(observation.get("player", 0))
    st = _STATE.get(player)
    if st is None or int(observation.get("step", 0)) == 0:
        st = _STATE[player] = Planner(player)
    try:
        return st.act(observation)
    except Exception as e:  # never crash the episode
        return {"farmer": ["PASS"], "hands": [], "market": []}


agent = kaggle_submission_agent
