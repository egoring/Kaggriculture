# planner dev runner: our planner (seat 0) vs opponent file; prints daily money, animal counts, errors
import sys,importlib.util,traceback
from kaggle_environments import make
def load(p):
    s=importlib.util.spec_from_file_location('C'+str(abs(hash(p))),p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
A=load(sys.argv[1]); B=load(sys.argv[2]); seed=int(sys.argv[3]); verbose=len(sys.argv)>4
a=A.kaggle_submission_agent; b=getattr(B,'kaggle_submission_agent',None) or B.agent
env=make("kaggriculture",configuration={"seed":seed}); env.reset()
errs=0
for t in range(720):
    obs=[env._Environment__get_shared_state(i).observation for i in (0,1)]
    try: aa=A._STATE[0].act(obs[0]) if (t>0 and 0 in A._STATE) else a(obs[0],env.configuration)
    except Exception as e:
        errs+=1
        if errs<=3: traceback.print_exc()
        aa={'farmer':['PASS'],'hands':[],'market':[]}
    bb=b(obs[1],env.configuration)
    if t%24==0 or t==719:
        f=obs[0]['farms'][0]; an={}
        for row in f['tiles']:
            for tl in row:
                if isinstance(tl,dict) and 'animal' in tl: an[tl['animal']]=an.get(tl['animal'],0)+1
        sh={k:v for k,v in obs[0]['private']['shed'].items() if v}
        pl={}
        for row in f['tiles']:
            for tl in row:
                if isinstance(tl,dict) and tl.get('kind')=='PLANT': pl[tl['crop'][:3]]=pl.get(tl['crop'][:3],0)+1
        an['plants']=pl
        print(f"day {t//24:2d} money {f['money']:8.0f} (opp {obs[0]['farms'][1]['money']:8.0f}) hands {len(f['hands'])} animals {an} quads {f['unlocked_quadrants']} shed {sh}"+(f" mkt {aa.get('market')}" if verbose else ''),flush=True)
    env.step([aa,bb])
    if env.done: break
rw=[s.reward for s in env.state]; print('FINAL',rw,'margin %+.0f'%(rw[0]-rw[1]),'errors',errs)
