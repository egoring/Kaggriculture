# kaggriculture planner v2 (9/26) — self-written farm planner (no recorded routes).
# Engine: every tile has a daily to-do (animal: FEED/CARE/COLLECT/HARVEST; plant: WATER/FERTILIZE/HARVEST; empty: PLANT);
# tiles are clustered into per-unit circuits by proximity with a step budget; the shed is visited to pick up wheat
# and drop produce; everything in the shed is sold the same step (wheat feed reserve excepted).
# Farm plan: cows + sheep + geese for fertilizer/product, melons for the day-10 cash jump, wheat for feed, carrots later.
import math

P = dict(
    max_hands=12,              # fib hire cost: 12 hands = $376/day, 13 = $609, 14 = $986
    wheat_reserve_days=1,
    fert_sell_floor=15,
    steps_per_unit=22,         # planning budget per unit per day (23 available after the hour-0 hire)
)
ANIMALS = {"GOOSE": dict(cost=300, structure="COOP", first=4, interval=1, product="EGG"),
           "COW": dict(cost=400, structure="PASTURE", first=8, interval=2, product="MILK"),
           "SHEEP": dict(cost=500, structure="PASTURE", first=6, interval=3, product="WOOL")}
CROPS = {"WHEAT": dict(seed=10, first=2, maxday=4, ongoing=False, maxy=6),
         "CARROT": dict(seed=20, first=2, maxday=3, ongoing=False, maxy=4),
         "TOMATO": dict(seed=50, first=8, maxday=8, ongoing=True, interval=1, maxy=4),
         "STRAWBERRY": dict(seed=100, first=10, maxday=10, ongoing=True, interval=2, maxy=4),
         "MELON": dict(seed=80, first=10, maxday=12, ongoing=False, maxy=6)}
PRODUCTS = ["WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL", "FERTILIZER"]
SHED_TILES = [(4, 4), (5, 4), (4, 5), (5, 5)]
_STATE = {}


def _dist(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def _step_toward(pos, tgt):
    dx, dy = tgt[0] - pos[0], tgt[1] - pos[1]
    if abs(dx) >= abs(dy) and dx != 0:
        return ["EAST"] if dx > 0 else ["WEST"]
    if dy != 0:
        return ["SOUTH"] if dy > 0 else ["NORTH"]
    return ["PASS"]


def _nearest_shed(pos):
    return min(SHED_TILES, key=lambda t: _dist(pos, t))


# ---------------- farm plan (targets by day) ----------------
def plan_targets(day, money, n_tiles):
    """Target counts of animals and crop tiles, modelled on the public stack's build (6-49 reference dump)."""
    t = dict(COW=0, SHEEP=0, GOOSE=0, MELON=0, WHEAT=0, CARROT=0, STRAWBERRY=0, TOMATO=0)
    t["COW"] = 2 if day < 3 else (3 if day < 4 else (4 if day < 8 else 6))
    t["SHEEP"] = 2 if day < 9 else (4 if day < 10 else (5 if day < 11 else 6))
    t["GOOSE"] = 0 if day < 7 else (2 if day < 11 else (4 if day < 12 else 5))
    t["MELON"] = 12 if day <= 9 else 0
    t["WHEAT"] = 8 if day < 4 else (14 if day < 11 else (24 if day <= 25 else (30 if day <= 26 else 0)))
    t["STRAWBERRY"] = 0 if day < 6 else (4 if day < 7 else (12 if day < 8 else (15 if day < 9 else (19 if day < 12 else (32 if day <= 21 else (26 if day <= 23 else (13 if day <= 25 else 0)))))))
    t["CARROT"] = 0 if day < 25 else (13 if day < 26 else (19 if day < 27 else (33 if day < 28 else 0)))
    t["TOMATO"] = 0
    return t


class Planner:
    def __init__(self, player):
        self.player = player
        self.scripts = []; self.script_pos = []; self.script_day = -1

    # ---------- parsing ----------
    def parse(self, obs):
        self.obs = obs
        self.step = int(obs["step"]); self.day = self.step // 24; self.hour = self.step % 24
        farm = obs["farms"][self.player]
        self.farm = farm; self.money = float(farm["money"]); self.tiles = farm["tiles"]
        self.private = obs["private"]; self.shed = dict(self.private.get("shed") or {})
        self.seeds = dict(self.private.get("seeds") or {})
        self.invs = [dict(x) for x in (self.private.get("inventories") or [{}])]
        self.units = [tuple(farm["farmer"])] + [tuple(h) for h in farm["hands"]]
        while len(self.invs) < len(self.units):
            self.invs.append({})
        self.market = obs["market"]; self.prices = dict(self.market.get("prices") or {})
        self.quads = list(farm.get("unlocked_quadrants") or ["NW"])
        self.shops = list((obs.get("town") or {}).get("unlocked_shops") or [])
        self.animals = []; self.empty = []; self.weeds = []; self.plants = []; self.structs = []
        for y in range(10):
            for x in range(10):
                t = self.tiles[y][x]
                if t == "LOCKED":
                    continue
                if t is None:
                    self.empty.append((x, y))
                elif isinstance(t, dict):
                    if "animal" in t:
                        self.animals.append(((x, y), t))
                    elif t.get("kind") == "PLANT":
                        self.plants.append(((x, y), t))
                    elif t.get("kind") == "WEED":
                        self.weeds.append((x, y))
                    elif t.get("kind") in ("COOP", "PASTURE"):
                        self.structs.append(((x, y), t["kind"]))
        self.n_tiles = 25 * len(self.quads)

    def counts(self):
        c = {}
        for _, t in self.animals:
            c[t["animal"]] = c.get(t["animal"], 0) + 1
        for k in ANIMALS:
            c[k] = c.get(k, 0) + int(self.shed.get(k, 0)) + sum(int(inv.get(k, 0)) for inv in self.invs)
        for _, t in self.plants:
            c[t["crop"]] = c.get(t["crop"], 0) + 1
        return c

    def animals_total(self):
        return len(self.animals) + sum(int(self.shed.get(k, 0)) for k in ANIMALS) + sum(int(inv.get(k, 0)) for inv in self.invs for k in ANIMALS)

    # ---------- tile to-do ----------
    def plant_ready(self, t):
        c = CROPS[t["crop"]]; age = self.day - int(t.get("planted_day", self.day)); y = int(t.get("yield_units", 0))
        if y <= 0:
            return False
        if c["ongoing"]:
            return True
        return y >= c["maxy"] or age >= c["maxday"]

    def tile_todo(self, pos):
        """Ops still to do today on this tile, in execution order."""
        t = self.tiles[pos[1]][pos[0]]
        ops = []
        if isinstance(t, dict) and "animal" in t:
            if not t["fed_today"]:
                ops.append("FEED")
            if not t["cared_today"]:
                ops.append("CARE")
            if t.get("fertilizer_available"):
                ops.append("COLLECT_FERTILIZER")
            if t.get("yield_units", 0) > 0:
                ops.append("HARVEST")
        elif isinstance(t, dict) and t.get("kind") == "PLANT":
            if not t["watered_today"]:
                ops.append("WATER")
            c = CROPS[t["crop"]]; age = self.day - int(t.get("planted_day", self.day))
            win0 = (c["maxday"] + 1) // 2 if not c["ongoing"] else c["first"] - 1
            if int(t.get("fertilized_until_day", -1)) < self.day and win0 - 1 <= age <= c["maxday"] and t["crop"] in ("WHEAT", "CARROT", "MELON", "STRAWBERRY"):
                ops.append("FERTILIZE")
            if self.plant_ready(t):
                ops.append("HARVEST")
        return ops

    # ---------- daily circuits ----------
    def make_day_scripts(self):
        n = len(self.units)
        todo = {}
        for pos, t in self.animals:
            todo[pos] = self.tile_todo(pos)
        for pos, t in self.plants:
            todo[pos] = self.tile_todo(pos)
        # planting plan for empty tiles
        cnt = self.counts(); tgt = plan_targets(self.day, self.money, self.n_tiles)
        reserve_tiles = int(sum(self.shed.get(k, 0) for k in ANIMALS)) + sum(int(inv.get(k, 0)) for inv in self.invs for k in ANIMALS)
        empties = sorted(self.empty, key=lambda p: _dist(p, (4, 4)))
        plant_list = []
        seeds = dict(self.seeds)
        for crop in ("MELON", "STRAWBERRY", "WHEAT", "CARROT"):
            need = tgt.get(crop, 0) - cnt.get(crop, 0)
            while need > 0 and seeds.get(crop, 0) > 0 and len(empties) > reserve_tiles:
                p = empties.pop()   # farthest from shed for crops (animals stay near)
                plant_list.append((p, crop)); seeds[crop] -= 1; need -= 1
        for p, crop in plant_list:
            todo[p] = ["PLANT:" + crop, "WATER"]   # a plant unwatered on its planting day becomes a weed at midnight
        for p in self.weeds[:4]:
            todo[p] = ["DIG"]
        tiles = [p for p, ops in todo.items() if ops]
        def value(p):
            ops = todo[p]; t = self.tiles[p[1]][p[0]]
            v = 0
            if "HARVEST" in ops:
                if isinstance(t, dict) and "animal" in t:
                    v += 60
                else:
                    crop = t.get("crop") if isinstance(t, dict) else ""
                    v += {"MELON": 250, "STRAWBERRY": 150, "WHEAT": 60, "CARROT": 60, "TOMATO": 80}.get(crop, 50)
            if "FEED" in ops:
                v += 120 if (isinstance(t, dict) and int(t.get("consecutive_unfed", 0)) >= 1) else 90
            if "WATER" in ops:
                v += 100 if (isinstance(t, dict) and int(t.get("consecutive_unwatered", 0)) >= 1) else 40
            if any(o.startswith("PLANT") for o in ops):
                v += 30
            if "CARE" in ops:
                v += 15
            if "COLLECT_FERTILIZER" in ops:
                v += 15
            if "DIG" in ops:
                v += 5
            return v
        tiles.sort(key=lambda p: -value(p))
        # capacity-limited tile set (highest value first), then proximity round-robin clustering
        cap_total = n * P["steps_per_unit"] - 3 * n
        chosen = []; acc = 0
        for p in tiles:
            c = len(todo[p]) + 2
            if False:
                continue
            chosen.append(p); acc += c
        cur = [self.units[i] for i in range(n)]; used = [0] * n; chunks = [[] for _ in range(n)]
        wheat_need = [0] * n
        left = set(chosen); progress = True
        while left and progress:
            progress = False
            for i in range(n):
                if not left:
                    break
                p = min(left, key=lambda q: (_dist(cur[i], q), q))
                cost = _dist(cur[i], p) + len(todo[p])
                if used[i] + cost + 2 > P["steps_per_unit"] and chunks[i]:
                    continue
                left.remove(p); chunks[i].append(p); used[i] += cost; cur[i] = p; progress = True
                if "FEED" in todo[p]:
                    wheat_need[i] += 1
        for i in range(n):
            pts = chunks[i]
            hv = []
            rest = [p for p in pts if p not in hv]
            order = []; c = self.units[i]
            for group in (hv, rest):
                while group:
                    p = min(group, key=lambda q: _dist(c, q)); group.remove(p); order.append(p); c = p
            chunks[i] = order
        self.scripts = []
        for i in range(n):
            sc = []
            if wheat_need[i] > 0:
                sc.append(("PICKUP_WHEAT", wheat_need[i]))
            for p in chunks[i]:
                sc.append(("VISIT", p, list(todo[p])))
            sc.append(("DROP",))
            self.scripts.append(sc)
        self.script_pos = [0] * n; self.script_day = self.day

    def assign(self):
        n = len(self.units)
        if self.hour == 0:
            self.scripts = [[("DROP",)] for _ in range(n)]; self.script_pos = [0] * n; self.script_day = -1
        elif self.script_day != self.day or len(self.scripts) != n:
            self.make_day_scripts()
        acts = [None] * n
        taken = set()
        wheat = [int(inv.get("WHEAT", 0)) for inv in self.invs]
        fert = [int(inv.get("FERTILIZER", 0)) for inv in self.invs]
        carry = [sum(v for k, v in inv.items() if k in PRODUCTS and k != "WHEAT") for inv in self.invs]
        animals_carried = [{k: int(inv.get(k, 0)) for k in ANIMALS if inv.get(k, 0)} for inv in self.invs]
        shed_wheat = int(self.shed.get("WHEAT", 0))
        for i in range(n):
            pos = self.units[i]; sh = _nearest_shed(pos); dsh = _dist(pos, sh)
            # carrying an animal: place it (build a structure first if needed)
            if animals_carried[i]:
                kind = next(iter(animals_carried[i])); st = ANIMALS[kind]["structure"]
                free_structs = [p for p, k in self.structs if k == st and p not in taken]
                if free_structs:
                    tgt = min(free_structs, key=lambda p: _dist(pos, p)); taken.add(tgt)
                    acts[i] = ["PLACE", kind] if pos == tgt else _step_toward(pos, tgt)
                    continue
                empties = [p for p in self.empty if p not in taken]
                if empties:
                    tgt = min(empties, key=lambda p: (_dist(p, (4, 4)), _dist(pos, p))); taken.add(tgt)
                    acts[i] = ["BUILD_" + st] if pos == tgt else _step_toward(pos, tgt)
                    continue
            sc = self.scripts[i]; k = self.script_pos[i]
            hi_val = sum(int(self.invs[i].get(x, 0)) for x in ("MELON", "STRAWBERRY", "MILK", "WOOL"))
            if hi_val >= 6 and (k >= len(sc) or sc[k][0] != "DROP") and dsh <= 3:
                acts[i] = ["DROP"] if dsh == 0 else _step_toward(pos, sh)
                continue
            while k < len(sc) and acts[i] is None:
                item = sc[k]
                if item[0] == "PICKUP_WHEAT":
                    need = min(item[1], shed_wheat)
                    if wheat[i] >= item[1] or need <= 0:
                        k += 1; continue
                    if dsh == 0:
                        acts[i] = ["PICKUP", "WHEAT", need]; shed_wheat -= need; k += 1
                    else:
                        acts[i] = _step_toward(pos, sh)
                elif item[0] == "VISIT":
                    tgt, ops = item[1], item[2]
                    if pos != tgt:
                        acts[i] = _step_toward(pos, tgt); break
                    # execute the next applicable op on this tile
                    live = self.tile_todo(tgt)
                    t = self.tiles[tgt[1]][tgt[0]]
                    op = None
                    for o in ops:
                        if o.startswith("PLANT:"):
                            crop = o.split(":")[1]
                            if t is None and int(self.seeds.get(crop, 0)) > 0:
                                op = ["PLANT", crop]; self.seeds[crop] = int(self.seeds.get(crop, 0)) - 1
                            ops.remove(o); break
                        if o == "DIG":
                            ops.remove(o)
                            if isinstance(t, dict) and t.get("kind") == "WEED":
                                op = ["DIG"]
                            break
                        if o not in live and not (o == "WATER" and t is None):
                            ops.remove(o); continue
                        if o == "FEED" and wheat[i] <= 0:
                            ops.remove(o); continue
                        if o == "FERTILIZE" and fert[i] <= 0:
                            ops.remove(o); continue
                        op = [o]; ops.remove(o)
                        if o == "FEED":
                            wheat[i] -= 1
                        if o == "FERTILIZE":
                            fert[i] -= 1
                        break
                    if op is None:
                        k += 1; continue
                    acts[i] = op
                elif item[0] == "DROP":
                    if carry[i] <= 0 and wheat[i] <= 0:
                        k += 1; continue
                    if dsh == 0:
                        acts[i] = ["DROP"]; k += 1
                    else:
                        acts[i] = _step_toward(pos, sh)
                else:
                    k += 1
            self.script_pos[i] = k
            if acts[i] is not None:
                continue
            # extras after the script: fetch animals from the shed, otherwise idle near the shed
            if any(int(self.shed.get(kk, 0)) > 0 for kk in ANIMALS) and self.day < 29:
                if dsh == 0:
                    kind = next(kk for kk in ANIMALS if int(self.shed.get(kk, 0)) > 0)
                    q = min(int(self.shed.get(kind, 0)), 2)
                    acts[i] = ["PICKUP", kind, q]; self.shed[kind] = int(self.shed.get(kind, 0)) - q
                else:
                    acts[i] = _step_toward(pos, sh)
                continue
            acts[i] = ["DROP"] if (dsh == 0 and (carry[i] > 0 or wheat[i] > 0)) else (_step_toward(pos, sh) if dsh > 1 else ["PASS"])
        return acts

    # ---------- market ----------
    def market_orders(self):
        orders = []
        cnt = self.counts(); tgt = plan_targets(self.day, self.money, self.n_tiles)
        n_anim = self.animals_total()
        if self.hour == 0 and self.day < 29:
            work = n_anim * 4 + len(self.plants) * 1.6 + 6
            want = int(min(P["max_hands"], max(3, math.ceil(work / 14))))
            orders += [["HIRE"]] * want
        reserve = n_anim * P["wheat_reserve_days"]
        sells = []
        for item in PRODUCTS:
            q = int(self.shed.get(item, 0))
            if item == "WHEAT":
                q -= (0 if self.step >= 716 else reserve + 6)
            if item == "FERTILIZER" and int(self.prices.get(item, 0)) < P["fert_sell_floor"] and self.step < 716 and sum(self.shed.values()) < 70:
                q = 0
            if q > 0:
                sells.append(["SELL", item, q])
        sells.sort(key=lambda o: -int(self.prices.get(o[1], 0)) * o[2])
        orders += sells
        money = self.money + sum(int(self.prices.get(o[1], 0)) * o[2] for o in sells) * 0.9
        money -= 100
        # wheat feed
        need_wheat = reserve + (1 if self.day > 0 else 4) - int(self.shed.get("WHEAT", 0))
        wp = int(self.prices.get("WHEAT", 25)) + 3
        cheap = int(self.prices.get("WHEAT", 25)) <= 32
        emergency = int(self.shed.get("WHEAT", 0)) < n_anim // 2
        if need_wheat > 0 and money > wp and self.hour in (0, 12) and True:
            q = min(need_wheat, 30, int(money // wp))
            if q > 0:
                orders.append(["BUY_PRODUCT", "WHEAT", q]); money -= q * wp
        if self.hour == 0 and self.day < 28:
            money -= 30 * n_anim   # tomorrow's feed
            # seeds for the planting plan
            free = len(self.empty) - int(sum(self.shed.get(k, 0) for k in ANIMALS))
            for crop in ("MELON", "STRAWBERRY", "WHEAT", "CARROT"):
                need = tgt.get(crop, 0) - cnt.get(crop, 0) - int(self.seeds.get(crop, 0))
                need = min(need, free)
                if need > 0 and money > CROPS[crop]["seed"] * need:
                    orders.append(["BUY_SEED", crop, need]); money -= CROPS[crop]["seed"] * need; free -= need
            # land
            for i, qn in enumerate(["NE", "SW", "SE"]):
                if qn in self.quads:
                    continue
                price = [1000, 2000, 4000][i]
                if ((i == 0 and self.day >= 7) or (i == 1 and self.day >= 12)) and money > price + 300 and self.day <= 18:
                    orders.append(["BUY_LAND"]); money -= price
                break
            # animals
            room = len(self.structs) + max(0, len(self.empty) - 4) - int(sum(self.shed.get(k, 0) for k in ANIMALS))
            for kind in ("COW", "SHEEP", "GOOSE"):
                need = tgt.get(kind, 0) - cnt.get(kind, 0)
                q = 0
                while need > 0 and room > 0 and money > ANIMALS[kind]["cost"] + 60 and q < 4:
                    q += 1; need -= 1; room -= 1; money -= ANIMALS[kind]["cost"] + 30
                if q > 0:
                    orders.append(["BUY_ANIMAL", kind, q])
        return orders[:10]

    def act(self, obs):
        self.parse(obs)
        acts = self.assign()
        for i, a in enumerate(acts):
            if a and a[0] == "DROP" and self.units[i] in SHED_TILES:
                for k, v in self.invs[i].items():
                    self.shed[k] = int(self.shed.get(k, 0)) + int(v)
        market = self.market_orders()
        return {"farmer": acts[0], "hands": acts[1:], "market": market}


def kaggle_submission_agent(observation, configuration=None):
    player = int(observation.get("player", 0))
    st = _STATE.get(player)
    if st is None or int(observation.get("step", 0)) == 0:
        st = _STATE[player] = Planner(player)
    try:
        return st.act(observation)
    except Exception:
        return {"farmer": ["PASS"], "hands": [], "market": []}


agent = kaggle_submission_agent
