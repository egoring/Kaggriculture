import base64,zlib,json,pickle,sys
# usage: mk_sub.py <base_submission.py> <rows.pkl> <rowkey> <out.py> <version_label>
base_py,rows_pkl,key,out,label=sys.argv[1:6]
src=open(base_py,encoding="utf-8").read()
line_i=[i for i,l in enumerate(src.split("\n")) if l.startswith("_D = json.loads")][0]
lines=src.split("\n"); line=lines[line_i]
blob=line[line.index('("')+2:line.rindex('")')]
D=json.loads(zlib.decompress(base64.b85decode(blob)))
acts=pickle.load(open(rows_pkl,"rb"))[key]
assert len(acts)==719
D["tapes"].append(acts); D["metas"].append({"src":key}); 
n=len(D["tapes"])
# prefix: 새 대본과 기존 대본들의 접두 일치 길이
def pref(a,b):
    k=0
    while k<719 and a[k]==b[k]: k+=1
    return k
for row in D["prefix"]: row.append(pref(D["tapes"][D["prefix"].index(row)] if False else D["tapes"][len(row)-1-0], acts) if False else 0)
D["prefix"].append([0]*n)
enc=base64.b85encode(zlib.compress(json.dumps(D,separators=(",",":")).encode(),9)).decode()
lines[line_i]=line[:line.index('("')+2]+enc+line[line.rindex('")'):]
src="\n".join(lines)
import re
src=re.sub(r"_SINGLE_TAPE = \d+", f"_SINGLE_TAPE = {n-1}", src, count=1)
src=src.replace("v8.16", label, 1)
open(out,"w",encoding="utf-8").write(src)
print("wrote",out,"tape index",n-1,"tapes",n)
