import pickle,glob,collections,sys
recs=[]
for cp in glob.glob("recs_cache/*.pkl"): recs.extend(pickle.load(open(cp,"rb")))
byep=collections.defaultdict(list)
for r in recs: byep[r["ep"]].append(r)
LIVE={"Crop Dusta"}
def fam(r):
    if r["name"] in LIVE: return r["name"]+"(live)"
    s0=[x for x in (r["step0"] or []) if x[0]=="BUY_PRODUCT"]; wq=str(s0[0][2]) if s0 else "-"
    return wq+"/"+r["prof"]
if __name__=="__main__":
    names=sys.argv[1:]
    for nm in names:
        st=collections.defaultdict(lambda:[0,0,[]]); hashes=collections.Counter(); fams=collections.Counter(); seen=set()
        for ep,pair in byep.items():
            if len(pair)!=2 or ep in seen: continue
            for me,op in ((pair[0],pair[1]),(pair[1],pair[0])):
                if me["name"]==nm:
                    seen.add(ep); f=fam(op); st[f][0 if me["win"] else 1]+=1; st[f][2].append(int(me["reward"]-op["reward"])); hashes[me["hash"][:6]]+=1; fams[fam(me)]+=1
        tot=sum(v[0]+v[1] for v in st.values()); w=sum(v[0] for v in st.values())
        print(f"== {nm}: {w}/{tot}  own families {fams.most_common(4)}  distinct hashes {len(hashes)} top {hashes.most_common(3)}")
        for f,v in sorted(st.items(),key=lambda kv:-(kv[1][0]+kv[1][1]))[:10]:
            print(f"     vs {f:18s} {v[0]}/{v[0]+v[1]}  margin {sum(v[2])/len(v[2]):+7.0f}")
