import importlib.util,sys,collections,pickle
from kaggle_environments import make
from matrix import mk
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m.agent
A=load(sys.argv[1],"A"); B=mk(pickle.load(open("cols_v9.pkl","rb"))[sys.argv[2]])
env=make("kaggriculture",configuration={"seed":int(sys.argv[3])}); env.run([A,B]); st=env.steps
d0,d1=int(sys.argv[4]),int(sys.argv[5])
for seat in (0,1):
    prod=0; lost=0; fert_prod=0; unw_prod=0; events=0
    for d in range(d0,d1):
        a_=st[d*24+23][seat].observation["farms"][seat]["tiles"]; b_=st[d*24+24][seat].observation["farms"][seat]["tiles"]
        for y in range(10):
            for x in range(10):
                ta,tb=a_[y][x],b_[y][x]
                if isinstance(ta,dict) and ta.get("crop")=="STRAWBERRY" and isinstance(tb,dict) and tb.get("crop")=="STRAWBERRY":
                    age=d-ta["planted_day"]
                    if age in (9,11,13,15):
                        events+=1
                        f = ta["watered_today"] and ta.get("fertilized_until_day",-1)>=d
                        want=2 if f else 1; got=tb["yield_units"]-ta["yield_units"]
                        prod+=got; lost+=max(0,want-got); fert_prod+=f
    print("seat",seat,"strawberry production events",events,"units produced",prod,"lost to cap",lost,"fertilized events",fert_prod)
