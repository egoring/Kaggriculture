"""하이브리드: 대본(v8.19) 으로 전반 실행 → SWITCH 스텝부터 라이브 엔진(engine_v10) 이 이어받음."""
import importlib.util, os
_HERE = "/root/kg"
def _load(p, n):
    s = importlib.util.spec_from_file_location(n, p); m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
_T = _load(os.path.join(_HERE, "submission_v819.py"), "hy_tape")
_E = _load(os.path.join(_HERE, "engine_v10.py"), "hy_engine")
SWITCH = int(os.environ.get("KG_SWITCH", "288"))
def agent(obs, cfg=None):
    step = int(obs["step"]) if isinstance(obs, dict) else int(getattr(obs, "step", 0))
    if step < SWITCH:
        return _T.agent(obs, cfg)
    return _E.agent(obs, cfg)
_submission_agent = agent
